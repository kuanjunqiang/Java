/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;
import game.PortableItem;

/**
 *
 * @author Asus
 */
public class FeedAction extends Action{
    private Item target;
    public FeedAction(Item item){
        target=item;
    }
    @Override
    public String execute(Actor actor,GameMap map){
        int y=map.locationOf(actor).y();
        int x=map.locationOf(actor).x();
        if(target.getDisplayChar()==','){
            if ((y != 24) && (map.at(x, y + 1).getDisplayChar() == 'D' ) || (y != 24) && (map.at(x, y + 1).getDisplayChar() == 'U' )){
                Stegosaur stegosaur=(Stegosaur)(map.at(x, y+1).getActor());
                stegosaur.eating("Hay");
            }
            else if((x!=79)&&map.at(x+1, y).getDisplayChar() == 'D' || (x!=79)&&map.at(x+1, y).getDisplayChar() == 'U'){
                Stegosaur stegosaur=(Stegosaur)map.at(x+1, y).getActor();
                stegosaur.eating("Hay");
            }
            else if((y!=0)&&map.at(x, y - 1).getDisplayChar() == 'D' || (y!=0)&&map.at(x, y - 1).getDisplayChar() == 'U'){
                Stegosaur stegosaur=(Stegosaur)map.at(x, y-1).getActor();
                stegosaur.eating("Hay");
            }
            else if((x!=0)&& map.at(x-1, y).getDisplayChar() == 'D' || (x!=0)&& map.at(x-1, y).getDisplayChar() == 'U'){
                Stegosaur stegosaur=(Stegosaur)map.at(x-1, y).getActor();
                stegosaur.eating("Hay");
            }
            actor.removeItemFromInventory(target);
            map.addPoints(10);
            return menuDescription(actor);
        }
        else if(target.getDisplayChar()=='`'){
            if ((y != 24) && (map.at(x, y + 1).getDisplayChar() == 'D' ) || (y != 24) && (map.at(x, y + 1).getDisplayChar() == 'U' )){
                Stegosaur stegosaur=(Stegosaur)(map.at(x, y+1).getActor());
                stegosaur.eating("Fruit");
            }
            else if((x!=79)&&map.at(x+1, y).getDisplayChar() == 'D' || (x!=79)&&map.at(x+1, y).getDisplayChar() == 'U'){
                Stegosaur stegosaur=(Stegosaur)map.at(x+1, y).getActor();
                stegosaur.eating("Fruit");
            }
            else if((y!=0)&&map.at(x, y - 1).getDisplayChar() == 'D' || (y!=0)&&map.at(x, y - 1).getDisplayChar() == 'U'){
                Stegosaur stegosaur=(Stegosaur)map.at(x, y-1).getActor();
                stegosaur.eating("Fruit");
            }
            else if((x!=0)&& map.at(x-1, y).getDisplayChar() == 'D' || (x!=0)&& map.at(x-1, y).getDisplayChar() == 'U'){
                Stegosaur stegosaur=(Stegosaur)map.at(x-1, y).getActor();
                stegosaur.eating("Fruit");
            }
            actor.removeItemFromInventory(target);
            map.addPoints(15);
            return menuDescription(actor);
        }
        else if(target.getDisplayChar()=='H'){
            if ((y != 24) && (map.at(x, y + 1).getDisplayChar() == 'D' ) || (y != 24) && (map.at(x, y + 1).getDisplayChar() == 'U' )){
                Stegosaur stegosaur=(Stegosaur)(map.at(x, y+1).getActor());
                stegosaur.eating("HerbivoreMealKit");
            }
            else if((x!=79)&&map.at(x+1, y).getDisplayChar() == 'D' || (x!=79)&&map.at(x+1, y).getDisplayChar() == 'U'){
                Stegosaur stegosaur=(Stegosaur)map.at(x+1, y).getActor();
                stegosaur.eating("HerbivoreMealKit");
            }
            else if((y!=0)&&map.at(x, y - 1).getDisplayChar() == 'D' || (y!=0)&&map.at(x, y - 1).getDisplayChar() == 'U'){
                Stegosaur stegosaur=(Stegosaur)map.at(x, y-1).getActor();
                stegosaur.eating("HerbivoreMealKit");
            }
            else if((x!=0)&& map.at(x-1, y).getDisplayChar() == 'D' || (x!=0)&& map.at(x-1, y).getDisplayChar() == 'U'){
                Stegosaur stegosaur=(Stegosaur)map.at(x-1, y).getActor();
                stegosaur.eating("HerbivoreMealKit");
            }
            actor.removeItemFromInventory(target);
            map.addPoints(50);
            return menuDescription(actor);
        }
        else if(target.getDisplayChar()=='C'){
            if ((y != 24) && (map.at(x, y + 1).getDisplayChar() == 'A' ) || (y != 24) && (map.at(x, y + 1).getDisplayChar() == 'W' )){
                Stegosaur stegosaur=(Stegosaur)(map.at(x, y+1).getActor());
                stegosaur.eating("CarnivoreMealKit");
            }
            else if((x!=79)&&map.at(x+1, y).getDisplayChar() == 'A' || (x!=79)&&map.at(x+1, y).getDisplayChar() == 'U' || (x!=79)&&map.at(x+1, y).getDisplayChar() == 'W'){
                Stegosaur stegosaur=(Stegosaur)map.at(x+1, y).getActor();
                stegosaur.eating("CarnivoreMealKit");
            }
            else if((y!=0)&&map.at(x, y - 1).getDisplayChar() == 'A' || (y!=0)&&map.at(x, y - 1).getDisplayChar() == 'U' || (y!=0)&&map.at(x, y - 1).getDisplayChar() == 'W'){
                Stegosaur stegosaur=(Stegosaur)map.at(x, y-1).getActor();
                stegosaur.eating("CarnivoreMealKit");
            }
            else if((x!=0)&& map.at(x-1, y).getDisplayChar() == 'A' || (x!=0)&& map.at(x-1, y).getDisplayChar() == 'U' || (x!=0)&& map.at(x-1, y).getDisplayChar() == 'W'){
                Stegosaur stegosaur=(Stegosaur)map.at(x-1, y).getActor();
                stegosaur.eating("CarnivoreMealKit");
            }
            actor.removeItemFromInventory(target);
            map.addPoints(100);
            return menuDescription(actor);
        }
        else if(target.getDisplayChar()=='o'){
            if ((y != 24) && (map.at(x, y + 1).getDisplayChar() == 'A' ) || (y != 24) && (map.at(x, y + 1).getDisplayChar() == 'U' ) || (y != 24) && (map.at(x, y + 1).getDisplayChar() == 'W' )){
                Stegosaur stegosaur=(Stegosaur)(map.at(x, y+1).getActor());
                stegosaur.eating("StegosaurEgg");
            }
            else if((x!=79)&&map.at(x+1, y).getDisplayChar() == 'A' || (x!=79)&&map.at(x+1, y).getDisplayChar() == 'U' || (x!=79)&&map.at(x+1, y).getDisplayChar() == 'W'){
                Stegosaur stegosaur=(Stegosaur)map.at(x+1, y).getActor();
                stegosaur.eating("StegosaurEgg");
            }
            else if((y!=0)&&map.at(x, y - 1).getDisplayChar() == 'A' || (y!=0)&&map.at(x, y - 1).getDisplayChar() == 'U' || (y!=0)&&map.at(x, y - 1).getDisplayChar() == 'W'){
                Stegosaur stegosaur=(Stegosaur)map.at(x, y-1).getActor();
                stegosaur.eating("StegosaurEgg");
            }
            else if((x!=0)&& map.at(x-1, y).getDisplayChar() == 'A' || (x!=0)&& map.at(x-1, y).getDisplayChar() == 'U' || (x!=0)&& map.at(x-1, y).getDisplayChar() == 'W'){
                Stegosaur stegosaur=(Stegosaur)map.at(x-1, y).getActor();
                stegosaur.eating("StegosaurEgg");
            }
            actor.removeItemFromInventory(target);
            map.addPoints(20);
            return menuDescription(actor);
        }
        return null;
    }
    
    @Override
    public String menuDescription(Actor actor){
        return actor + " feeds " + actor.toString() + " with "+target.toString();
    }
}

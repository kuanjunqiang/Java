package game;

public class CarnivoreMealKit extends PortableItem{
    public CarnivoreMealKit() {
        super("CarnivoreMealKit", 'C');
    }
}

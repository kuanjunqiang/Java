/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Item;

/**
 * The body of a dead Allosaur
 */
public class DeadDinosaur extends Item {

    public DeadDinosaur() {
        super("DeadDinosaur", '%', false);
    }
}

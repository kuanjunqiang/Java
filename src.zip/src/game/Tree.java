package game;

import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.Item;
import java.util.*;

public class Tree extends Ground {

    private int age = 0;
    private int fruitAge = 0;
    private int countT=0;

    public Tree() {
        super('+');
    }

    public int rand100() {
        return (int) (100 * Math.random() + 1);
    }

    @Override
    public void tick(Location location) {
        super.tick(location);

        age++;
        if(fruitAge!=0){
            fruitAge++;
        }
        if (age == 10) {
            displayChar = 't';
        }
        if (age == 20) {
            displayChar = 'T';
        }
        List<Item> items;
        items = location.getItems();
        for (Item item : items) {
            if (fruitAge == 20) {
                Item temp = item;
                location.removeItem(temp);
                if (age < 10) {
                    displayChar = '+';
                } else if (age < 20) {
                    displayChar = 't';
                } else {
                    displayChar = 'T';
                }
            }
        }
        if (rand100() <= 5&&fruitAge==0) {
            Item fruit = new Fruit();
            location.addItem(fruit);
            fruitAge = 1;
        }
        if(!location.getItems().contains("Fruit")&&displayChar=='`'){
            if(age<10){
                    displayChar='+';
                }
                else if(age<20){
                    displayChar='t';
                }
                else{
                    displayChar='T';
                }
        }
    }
}

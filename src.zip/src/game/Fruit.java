/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Item;
/**
 *
 * @author Asus
 */
public class Fruit extends PortableItem{
    public Fruit() {
		super("Fruit", '`');
    }
}

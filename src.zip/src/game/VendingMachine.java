package game;

import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Item;

/**
 * A class for a vending machine.
 */
public class VendingMachine extends Ground {
    /***
     * Constructor.
     */
    public VendingMachine() {
        super('V');
    }
}

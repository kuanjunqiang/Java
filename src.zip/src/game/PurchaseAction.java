package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Item;

public class PurchaseAction extends Action {

    String target;

    public PurchaseAction(String item){
        target = item;
    }

    /**
     * Perform the Action.
     *
     * @param actor The actor performing the action.
     * @param map   The map the actor is on.
     * @return a description of what happened that can be displayed to the user.
     */
    @Override
    public String execute(Actor actor, GameMap map) {
        if (map.locationOf(actor).getGround().getDisplayChar() == 'V') {
            if (target.equals("Hay")) {
                if (map.getPoints() >= 20) {
                    Item hay = new Hay();
                    actor.addItemToInventory(hay);
                    map.reducePoints(20);
                }
            } else if (target.equals("Fruit")) {
                if (map.getPoints() >= 30) {
                    Item fruit = new Fruit();
                    actor.addItemToInventory(fruit);
                    map.reducePoints(30);
                }
            } else if (target.equals("VegetarianMealKit")) {
                if (map.getPoints() >= 100) {
                    Item herbivoreMealKit = new HerbivoreMealKit();
                    actor.addItemToInventory(herbivoreMealKit);
                    map.reducePoints(100);
                }
            } else if (target.equals("CarnivoreMealKit")) {
                if (map.getPoints() >= 500) {
                    Item carnivoreMealKit = new CarnivoreMealKit();
                    actor.addItemToInventory(carnivoreMealKit);
                    map.reducePoints(500);
                }
            } else if (target.equals("StegosaurEgg")) {
                if (map.getPoints() >= 200) {
                    Item stegosaurEgg = new StegosaurEgg();
                    actor.addItemToInventory(stegosaurEgg);
                    map.reducePoints(200);
                }
            } else if (target.equals("AllosaurEgg")) {
                if (map.getPoints() >= 1000) {
                    Item allosaurEgg = new AllosaurEgg();
                    actor.addItemToInventory(allosaurEgg);
                    map.reducePoints(1000);
                }
            } else if (target.equals("AgilisaurusEgg")) {
                if (map.getPoints() >= 600) {
                    Item agilisaurusEgg = new AgilisaurusEgg();
                    actor.addItemToInventory(agilisaurusEgg);
                    map.reducePoints(600);
                }
            } else if (target.equals("ArchaeopteryxEgg")) {
                if (map.getPoints() >= 600) {
                    Item archaeopteryxEgg = new ArchaeopteryxEgg();
                    actor.addItemToInventory(archaeopteryxEgg);
                    map.reducePoints(600);
                }
            } else if (target.equals("LaserGun")) {
                if (map.getPoints() >= 500) {
                    Item laserGun = new LaserGun();
                    actor.addItemToInventory(laserGun);
                    map.reducePoints(500);
                }
            }
            return null;
        }
        return menuDescription(actor);
    }


    /**
     * Returns a descriptive string
     *
     * @param actor The actor performing the action.
     * @return the text we put on the menu
     */
    @Override
    public String menuDescription(Actor actor) {
        return actor + " purchases the "+ target;
    }
}

package game;

/**
 * The egg of an Allosaur
 */
public class AllosaurEgg extends PortableItem{
    public AllosaurEgg() {
        super("AllosaurEgg", '0');
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.*;

/**
 * A class that figures out a food source for an Allosaur
 */
public class CarnivoreBehaviour implements Behaviour{

    /**
     * Compute the Manhattan distance between two locations.
     *
     * @param a the first location
     * @param b the first location
     * @return the number of steps between a and b if you only move in the four cardinal directions.
     */
    private int distance(Location a, Location b) {
        return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
    }

    /**
     * Returns a MoveAction or CarnivoreAction to move to a food source, if possible. If no
     * movement is possible, returns null.
     *
     * @param actor the Actor enacting the behaviour
     * @param map the map that actor is currently on
     * @return an Action, or null if no MoveAction/CarnivoreAction is possible
     */
    @Override
    public Action getAction(Actor actor, GameMap map) {
        if (!map.contains(actor)) {
            return null;
        }
        int min = 100; // record the shortest distance between the actor and ground target and actor will tend to move there
        int minX=100;
        int minY=100;
        // run through out whole map to find the nearest food
        for (int x = 0; x < 80; x++) {
            for (int y = 0; y < 25; y++) {
                Location here = map.locationOf(actor);
                Location there = map.at(x, y);

                if (map.at(x, y).getDisplayChar() == 'D'||map.at(x, y).getDisplayChar() == 'o' || map.at(x, y).getDisplayChar() == '%'||map.at(x, y).getDisplayChar() == 'C'){
                    int currentDistance = distance(here, there);
                    if (currentDistance <= min) {
                        min = currentDistance;
                        minX=x;
                        minY=y;
                    }
                }
            }
        }
//        Move towards food source and does CarnivoreAction
        Location here = map.locationOf(actor);
        Location there = map.at(minX, minY);
        int currentDistance = distance(here, there);
        for (Exit exit : here.getExits()) {
            Location destination = exit.getDestination();
            if (destination.canActorEnter(actor)) {
                int newDistance = distance(destination, there);
                if (newDistance < currentDistance) {
                    return new MoveActorAction(destination, exit.getName());
                }
                else if(newDistance==currentDistance){
                    return new CarnivoreAction();
                }
            }
        }
        return null;
    }
}
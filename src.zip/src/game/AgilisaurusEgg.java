package game;

/**
 * The egg of an Agilisaurus
 */
public class AgilisaurusEgg extends PortableItem{
    public AgilisaurusEgg() {
        super("AgilisaurusEgg", 'O');
    }
}

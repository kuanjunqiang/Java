package game;

/**
 * A herbivore meal kit item.
 */
public class HerbivoreMealKit extends PortableItem{
    public HerbivoreMealKit() {
        super("HerbivoreMealKit", 'H');
    }
}

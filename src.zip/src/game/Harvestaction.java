/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;
import game.PortableItem;

/**
 *
 * @author Asus
 */
public class HarvestAction extends Action {

    String target;
    public HarvestAction(String item) {
        target=item;
    }

    @Override
    public String execute(Actor actor, GameMap map) {
        if (map.locationOf(actor).getGround().getDisplayChar() == ',') {
            target="Grass";
            for(Item item:map.locationOf(actor).getItems()){
                if(item.getDisplayChar()==','){
                    map.locationOf(actor).removeItem(item);
                    actor.addItemToInventory(item);
                    map.addPoints(1);
                    break;
                }
            }
            map.locationOf(actor).getGround().setDisplayChar('.');
            return menuDescription(actor);
        }
        else if (map.locationOf(actor).getGround().getDisplayChar() == 'T'||map.locationOf(actor).getGround().getDisplayChar() == 't'||map.locationOf(actor).getGround().getDisplayChar() == '+') {
            target="Fruit";
            if(rand100()<=40){
                Item fruit=new PortableItem("Fruit",'`');
                map.locationOf(actor).removeItem(fruit);
                actor.addItemToInventory(fruit);
                return menuDescription(actor);
            }
            else{
                return "You search the tree for fruit, but you can't find any ripe ones";
            }
        }
        return null;
    }

    public int rand100() {
        return (int) (100 * Math.random() + 1);
    }
    
    @Override
    public String menuDescription(Actor actor) {
        return actor + " harvests the "+target;
    }
}

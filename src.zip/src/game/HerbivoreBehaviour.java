/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Exit;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.MoveActorAction;

/**
 *
 * @author Asus
 */
public class HerbivoreBehaviour implements Behaviour {

    public HerbivoreBehaviour() {
    }

    private int distance(Location a, Location b) {
        return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
    }

    @Override
    public Action getAction(Actor actor, GameMap map) {
        if (!map.contains(actor)) {
            return null;
        }
        int min = 100; // record the shortest distance between the actor and ground targer and actor will tend to move there
        int minX = 100;
        int minY = 100;
        // run through out whole map to find the nearest food
        for (int x = 0; x < 80; x++) {
            for (int y = 0; y < 25; y++) {
                Location here = map.locationOf(actor);
                Location there = map.at(x, y);

                if (map.at(x, y).getGround().getDisplayChar() == ',' || map.at(x, y).getGround().getDisplayChar() == '`' || map.at(x, y).getGround().getDisplayChar() == 'H') {
                    int currentDistance = distance(here, there);
                    if (currentDistance < min) {
                        min = currentDistance;
                        minX = x;
                        minY = y;
                    }
                }
            }
        }
        Location here = map.locationOf(actor);
        Location there = map.at(minX, minY);
        int currentDistance = distance(here, there);
        for (Exit exit : here.getExits()) {
            Location destination = exit.getDestination();
            if (destination.canActorEnter(actor)) {
                if (currentDistance == 0) {
                    return new HerbivoreAction();
                } else {
                    int newDistance = distance(destination, there);
                    if (newDistance < currentDistance) {
                        return new MoveActorAction(destination, exit.getName());
                    }
                }

            }
        }
        return null;
    }
}

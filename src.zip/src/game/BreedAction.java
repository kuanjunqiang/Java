/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Exit;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.MoveActorAction;

/**
 *
 * @author Asus
 */
public class BreedAction extends Action {

    protected String target;

    public BreedAction() {
    }

    @Override
    public String execute(Actor actor, GameMap map) {
//        int x = map.locationOf(actor).x();
//        int y = map.locationOf(actor).y();
//        if ((y != 24 && map.at(x, y + 1).getDisplayChar() == 'D')) {
//            if (((Stegosaur) actor).getGender() == 'F') {
//                ((Stegosaur) actor).pregnant();
//            } else if (((Stegosaur) map.getActorAt(map.at(x, y + 1))).getGender() == 'F') {
//                ((Stegosaur) (map.getActorAt(map.at(x, y + 1)))).pregnant();
//            }
//            return menuDescription(actor);
//        } else if ((y != 0 && map.at(x, y - 1).getDisplayChar() == 'D')) {
//            if (((Stegosaur) actor).getGender() == 'F') {
//                ((Stegosaur) actor).pregnant();
//            } else if (((Stegosaur) map.getActorAt(map.at(x, y - 1))).getGender() == 'F') {
//                ((Stegosaur) (map.getActorAt(map.at(x, y - 1)))).pregnant();
//            }
//            return menuDescription(actor);
//        } else if ((x != 79 && map.at(x + 1, y).getDisplayChar() == 'D')) {
//            if (((Stegosaur) actor).getGender() == 'F') {
//                ((Stegosaur) actor).pregnant();
//            } else if (((Stegosaur) map.getActorAt(map.at(x+1, y))).getGender() == 'F') {
//                ((Stegosaur) (map.getActorAt(map.at(x+1, y)))).pregnant();
//            }
//            return menuDescription(actor);
//        } else if ((x != 0 && map.at(x - 1, y).getDisplayChar() == 'D')) {
//            if (((Stegosaur) actor).getGender() == 'F') {
//                ((Stegosaur) actor).pregnant();
//            } else if (((Stegosaur) map.getActorAt(map.at(x-1, y ))).getGender() == 'F') {
//                ((Stegosaur) (map.getActorAt(map.at(x-1, y)))).pregnant();
//            }
//            return menuDescription(actor);
//        }
//        return null;
        ((Stegosaur)actor).pregnant();
        return menuDescription(actor);
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " mates and female Stegosaur is pregnant";
    }
}

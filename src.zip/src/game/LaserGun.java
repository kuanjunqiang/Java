package game;

import edu.monash.fit2099.engine.WeaponItem;

/**
 * A laser gun item
 */
public class LaserGun extends WeaponItem {
    /**
     * Constructor. Represented by L, has 20 damage from zaps.
     *
     */
    public LaserGun() {
        super("LaserGun", 'L', 50, "zaps");
    }
}

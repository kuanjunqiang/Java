/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Item;

/**
 *
 * @author Asus
 */
public class DrinkAction extends Action{

    
    public DrinkAction() {
    }

    @Override
    public String execute(Actor actor, GameMap map) {
        int x=map.locationOf(actor).x();
        int y=map.locationOf(actor).y();
        if (((x != 0) && map.at(x - 1, y).getDisplayChar() == '~')||((y != 0)&&map.at(x , y-1).getDisplayChar() == '~')||((x!=79)&&map.at(x+1 , y).getDisplayChar() == '~')||(y!=24&&map.at(x, y+1).getDisplayChar() == '~')) {
            ((Stegosaur)actor).drinking();
            return menuDescription(actor);
        }
        return null;
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " drinks water";
    }
}

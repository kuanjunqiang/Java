package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Menu;

import java.util.ArrayList;
import java.util.List;

/**
 * Class representing Dinosaurs (Stegosaur, Allosaur)
 */
public abstract class Dinosaur extends Actor {

    public List<Behaviour> behaviours = new ArrayList<Behaviour>();
    private Menu menu = new Menu();
    private int foodLevel = 0;
    private final int MAX = 100;
    private int turn = 0;
    private char sex;

    /**
     * Constructor. All Dinosaurs are represented by a character and have 100 hit
     * points.
     *
     * @param name Name of the dinosaur (Stegosaur/Allosaur)
     * @param displayChar Display character symbol
     * @param sex Gender of the dinosaur (m/f)
     */
    public Dinosaur(String name, char displayChar, char sex){
        super(name, displayChar, 100);
        foodLevel = 50;
        behaviours.add(new WanderBehaviour());
        if(sex == 'm' || sex == 'f'){
            this.sex = sex;
        }
    }

    public abstract void eating(String str);

    /**
     * A method to return whether or not Dinosaur is conscious or not.
     *
     * @return boolean whether or not Stegosaur is conscious.
     */
    public abstract boolean isConscious();


    /**
     * A method to return whether or not Dinosaur is hungry or not.
     *
     * @return boolean whether or not Dinosaur is hungry
     */
    public abstract boolean isHungry();
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.Ground;
/**
 *
 * @author Asus
 */
public class GrowingEgg extends Ground{
    private int eggAge = 0;
    private char type;

    public GrowingEgg(char type) {
        super(type);
        this.type = type;
    }
    @Override
    public void tick(Location location) {
        super.tick(location);

        eggAge++;
        if (type == 'o'){
            if(eggAge==5){
                displayChar='.';
                System.out.println("The Stegosaur egg hatch and a small stegosaur is reproduced");
                location.addActor(new BabyStegosaur());
                location.map().addPoints(100);
            }
        }
        else if (type == '0'){
            if(eggAge==5){
                displayChar='.';
                System.out.println("The Allosaur egg hatch and a small allosaur is reproduced");
                location.addActor(new BabyAllosaur());
                location.map().addPoints(1000);
            }
        }
        else if (type == 'O'){
            if(eggAge==5){
                displayChar='.';
                System.out.println("The Agilisaurus egg hatch and a small agilisaurus is reproduced");
                location.addActor(new BabyAgilisaurus());
                location.map().addPoints(500);
            }
        }
        else if (type == '@'){
            if(eggAge==5){
                displayChar='.';
                System.out.println("The Archaeopteryx egg hatch and a small Archaeopteryx is reproduced");
                location.addActor(new BabyArchaeopteryx());
                location.map().addPoints(500);
            }
        }
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Display;
import edu.monash.fit2099.engine.FancyGroundFactory;
import edu.monash.fit2099.engine.World;
import edu.monash.fit2099.engine.ActorLocations;
import edu.monash.fit2099.engine.Item;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 *
 * @author Asus
 */
public class moveToAnotherMap extends Action {
    // use to know which map the player are in
    int x;

    public moveToAnotherMap(int x) {
        this.x=x;
    }

    @Override
    public String execute(Actor actor, GameMap map) {
        return menuDescription(actor);
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " moves to another map";
    }

    @Override
    public String hotkey() {
        if(x==1){
            return "8";
        }
        return "2";
    }
}

package game;

/**
 * The egg of an Archaeopteryx
 *
 */
public class ArchaeopteryxEgg extends PortableItem{
    public ArchaeopteryxEgg() {
        super("ArchaeopteryxEgg", '@');
    }
}

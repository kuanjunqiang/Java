/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actions;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Display;
import edu.monash.fit2099.engine.DoNothingAction;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.Menu;
import edu.monash.fit2099.engine.Item;
import java.util.Random;

/**
 *
 * @author Asus
 */
public class BabyStegosaur extends Actor {

    private Behaviour behaviour;
    private int foodLevel;
    private final int MAX = 100;
    private int turn = 0;
    private char gender;

    /**
     * Constructor. All Baby Stegosaurs are represented by a 'd' and have 100 hit
     * points.
     *
     */
    public BabyStegosaur() {
        super("babyStegosaur", 'd', 0);
        foodLevel = 10;
        turn++;
        behaviour = new WanderBehaviour();
        if (randomGender() == 1) {
            gender = 'M';
        } else {
            gender = 'F';
        }
    }

    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        turn++;
        Action wander = behaviour.getAction(this, map);
        if(turn==30){
            Location location=map.locationOf(this);
            map.removeActor(this);
            map.addActor(new Stegosaur("Stegosaur",gender),location);
            return null;
        }
        else if (wander != null) {
            foodLevel--;
            return wander;
        }
        return new DoNothingAction();
    }

    public char getGender() {
        return gender;
    }

    public int randomGender() {
        Random rand = new Random();
        return rand.nextInt(2) + 1;
    }
}

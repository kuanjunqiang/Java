package game;

import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Item;
import java.util.*;

/**
 * A class that represents bare dirt.
 */
public class Dirt extends Ground {

    private int age = 0;

    public Dirt() {
        super('.');
    }

    public int rand100() {
        return (int) (100 * Math.random() + 1);
    }

    @Override
    public void tick(Location location) {
        super.tick(location);

        // only at the beggining it will use this one
        // after the first turn it will consider the following conditions
        if (rand100() <= 2 && age == 0) {
            displayChar = ',';
            Item hay = new Hay();
            location.addItem(hay);
        }
        age++;

        GameMap map = location.map();
        int x = location.x();
        int y = location.y();

        ArrayList<Character> char1 = check(location);

        if (!char1.isEmpty()) {
            if ((y != 24) && (map.at(x, y + 1).getDisplayChar() == '+' || map.at(x, y + 1).getDisplayChar() == 't' || map.at(x, y + 1).getDisplayChar() == 'T') && rand100() <= 2) {
                displayChar = ',';
                Item hay = new Hay();
                location.addItem(hay);
                map.addPoints(1);
            }

            if ((y != 0) && (map.at(x, y - 1).getDisplayChar() == '+' || map.at(x, y - 1).getDisplayChar() == 't' || map.at(x, y - 1).getDisplayChar() == 'T') && rand100() <= 2) {
                displayChar = ',';
                Item hay = new Hay();
                location.addItem(hay);
                map.addPoints(1);
            }

            if ((x != 79) && (map.at(x + 1, y).getDisplayChar() == '+' || map.at(x + 1, y).getDisplayChar() == 't' || map.at(x + 1, y).getDisplayChar() == 'T') && rand100() <= 2) {
                displayChar = ',';
                Item hay = new Hay();
                location.addItem(hay);
                map.addPoints(1);
            }
            if ((x != 0) && (map.at(x - 1, y).getDisplayChar() == '+' || map.at(x - 1, y).getDisplayChar() == 't' || map.at(x - 1, y).getDisplayChar() == 'T') && rand100() <= 2) {
                displayChar = ',';
                Item hay = new Hay();
                location.addItem(hay);
                map.addPoints(1);
            }
        }

    }

    public ArrayList check(Location location) {
        GameMap map = location.map();
        ArrayList<Character> char1 = new ArrayList<>();
        int x = location.x();
        int y = location.y();
        if ((x != 0 && y != 0) && map.at(x - 1, y).getDisplayChar() == ',') {
            if (map.at(x - 1, y).getDisplayChar() == ',' && ((x != 1 && map.at(x - 2, y).getDisplayChar() == ',') || (y != 24 && map.at(x - 1, y + 1).getDisplayChar() == ',') || (y != 0 && map.at(x - 1, y - 1).getDisplayChar() == ','))) {
                char1.add(',');
            } else {
                char1.add('?');
            }
        }

        if ((x != 79 && map.at(x + 1, y).getDisplayChar() == ',') && ((x != 78 && map.at(x + 2, y).getDisplayChar() == ',') || (x != 79 && y != 24 && map.at(x + 1, y + 1).getDisplayChar() == ',') || (x != 79 && y != 0 && map.at(x + 1, y - 1).getDisplayChar() == ','))) {
            char1.add(',');
        } else {
            char1.add('?');
        }
        if ((y != 0 && map.at(x, y - 1).getDisplayChar() == ',') && ((x != 79 && y != 0 && map.at(x + 1, y - 1).getDisplayChar() == ',') || (x != 0 && y != 0 && map.at(x - 1, y - 1).getDisplayChar() == ',') || (y != 1 && map.at(x, y - 2).getDisplayChar() == ','))) {
            char1.add(',');
        } else {
            char1.add('?');
        }

        if ((y != 24 && map.at(x, y + 1).getDisplayChar() == ',') && ((x != 79 && y != 24 && map.at(x + 1, y + 1).getDisplayChar() == ',') || (x != 0 && y != 24 && map.at(x - 1, y + 1).getDisplayChar() == ',') || (y != 23 && map.at(x, y + 2).getDisplayChar() == ','))) {
            char1.add(',');
        } else {
            char1.add('?');
        }

        return char1;
    }
}

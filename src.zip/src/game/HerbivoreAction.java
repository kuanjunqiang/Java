/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Item;

/**
 *
 * @author Asus
 */
public class HerbivoreAction extends Action{

    protected String target;
    
    public HerbivoreAction() {
    }

    @Override
    public String execute(Actor actor, GameMap map) {
        //Grass
        if (map.locationOf(actor).getGround().getDisplayChar() == ',') {
            target="Grass";
            for(Item item:map.locationOf(actor).getItems()){
                if(item.getDisplayChar()==','){
                    map.locationOf(actor).removeItem(item);
                    map.locationOf(actor).getGround().setDisplayChar('.');
                    break;
                }
            }
            ((Stegosaur)actor).eating("Grass");
            return menuDescription(actor);
        }
        //fruit
        else if (map.locationOf(actor).getGround().toString().equals("Fruit")) {
            target="Fruit";
            for(Item item:map.locationOf(actor).getItems()){
                if(item.getDisplayChar()=='`'){
                    map.locationOf(actor).removeItem(item);
                    break;
                }
            }
            ((Stegosaur) actor).eating("Fruit");
            return menuDescription(actor);
        }
        //herbivore meal kit
        else if (map.locationOf(actor).getGround().toString().equals("HerbivoreMealKit")) {
            target="HerbivoreMealKit";
            for(Item item:map.locationOf(actor).getItems()){
                if(item.getDisplayChar()=='H'){
                    map.locationOf(actor).removeItem(item);
                    break;
                }
            }
            ((Stegosaur) actor).eating("HerbivoreMealKit");
            return menuDescription(actor);
        }
        //herbivore meal kit
        else if (map.locationOf(actor).getGround().toString().equals("Hay")) {
            target="Hay";
            for(Item item:map.locationOf(actor).getItems()){
                if(item.getDisplayChar()==','){
                    map.locationOf(actor).removeItem(item);
                    break;
                }
            }
            ((Stegosaur) actor).eating("HerbivoreMealKit");
            return menuDescription(actor);
        }
        //leave
//        else if (map.locationOf(actor).getDisplayChar() == '+'||map.locationOf(actor).getDisplayChar() == 't'||map.locationOf(actor).getDisplayChar() == 'T') {
//            target="Leave";
//            ((Stegosaur)actor).eating("Leave");
//            map.locationOf(actor).getGround().setDisplayChar('T');
//            return menuDescription(actor);
//        }
        return null;
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " eats " + target;
    }
}

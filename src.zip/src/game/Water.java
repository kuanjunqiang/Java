package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Location;

/**
 * A class that represents bare dirt.
 */
public class Water extends Ground {

    private int age = 0;

    public Water() {
        super('~');
    }

    @Override
    public void tick(Location location) {
        super.tick(location);
    }

    @Override
    public boolean canActorEnter(Actor actor) {
        return false;
    }
}

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package game;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Ground;
import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Exit;
import edu.monash.fit2099.engine.Location;
import edu.monash.fit2099.engine.Item;
import edu.monash.fit2099.engine.MoveActorAction;

/**
 * An action for Allosaurs to eat.
 */
public class CarnivoreAction extends Action{

    protected String target;

    @Override
    public String execute(Actor actor, GameMap map) {
        if (actor.toString().equals("Allosaur")){
            //Stegosaur
            if (map.locationOf(actor).getGround().getDisplayChar() == 'D') {
                target="Stegosaur";
                for(Item item:map.locationOf(actor).getItems()){
                    if(item.getDisplayChar()=='D'){
                        map.locationOf(actor).removeItem(item);
                        map.locationOf(actor).getGround().setDisplayChar('.');
                        break;
                    }
                }
                ((Allosaur)actor).eating("Stegosaur");
                return menuDescription(actor);
            }
            //Stegosaur egg
            else if (map.locationOf(actor).getGround().getDisplayChar() == ('o')) {
                target="StegosaurEgg";
                for(Item item:map.locationOf(actor).getItems()){
                    if(item.getDisplayChar()=='o'){
                        map.locationOf(actor).removeItem(item);
                        map.locationOf(actor).getGround().setDisplayChar('.');
                        break;
                    }
                }
                ((Allosaur) actor).eating("StegosaurEgg");
                return menuDescription(actor);
            }
//        Dead dinosaur
            else if (map.locationOf(actor).getGround().getDisplayChar() == ('%')) {
                target="DeadDinosaur";
                for(Item item:map.locationOf(actor).getItems()){
                    if(item.getDisplayChar()=='%'){
                        map.locationOf(actor).removeItem(item);
                        map.locationOf(actor).getGround().setDisplayChar('.');
                        break;
                    }
                }
                ((Allosaur) actor).eating("DeadDinosaur");
                return menuDescription(actor);
            }
        }
        else if(actor.toString().equals("Agilisaurus")){
            //Stegosaur egg
            if (map.locationOf(actor).getGround().getDisplayChar() == ('o')) {
                target="StegosaurEgg";
                for(Item item:map.locationOf(actor).getItems()){
                    if(item.getDisplayChar()=='o'){
                        map.locationOf(actor).removeItem(item);
                        map.locationOf(actor).getGround().setDisplayChar('.');
                        break;
                    }
                }
                ((Agilisaurus) actor).eating("StegosaurEgg");
                return menuDescription(actor);
            }
//        Dead dinosaur
            else if (map.locationOf(actor).getGround().getDisplayChar() == ('%')) {
                target="DeadDinosaur";
                for(Item item:map.locationOf(actor).getItems()){
                    if(item.getDisplayChar()=='%'){
                        map.locationOf(actor).removeItem(item);
                        map.locationOf(actor).getGround().setDisplayChar('.');
                        break;
                    }
                }
                ((Agilisaurus) actor).eating("DeadDinosaur");
                return menuDescription(actor);
            }
        }
        else if(actor.toString().equals("Archaeopteryx")){
            //Stegosaur egg
            if (map.locationOf(actor).getGround().getDisplayChar() == ('o')) {
                target="StegosaurEgg";
                for(Item item:map.locationOf(actor).getItems()){
                    if(item.getDisplayChar()=='o'){
                        map.locationOf(actor).removeItem(item);
                        map.locationOf(actor).getGround().setDisplayChar('.');
                        break;
                    }
                }
                ((Archaeopteryx) actor).eating("StegosaurEgg");
                return menuDescription(actor);
            }
//        Dead dinosaur
            else if (map.locationOf(actor).getGround().getDisplayChar() == ('%')) {
                target="DeadDinosaur";
                for(Item item:map.locationOf(actor).getItems()){
                    if(item.getDisplayChar()=='%'){
                        map.locationOf(actor).removeItem(item);
                        map.locationOf(actor).getGround().setDisplayChar('.');
                        break;
                    }
                }
                ((Archaeopteryx) actor).eating("DeadDinosaur");
                return menuDescription(actor);
            }
        }
        return null;
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " eats " + target;
    }
}
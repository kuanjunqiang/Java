package game;

import edu.monash.fit2099.engine.Action;
import edu.monash.fit2099.engine.Actions;
import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Display;
import edu.monash.fit2099.engine.DoNothingAction;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.Menu;
import edu.monash.fit2099.engine.Item;

/**
 * An omnivorous dinosaur.
 *
 */
public class Agilisaurus extends Actor {

    private Behaviour behaviour;
    private Menu menu = new Menu();
    private int foodLevel;
    private final int MAX = 100;
    private int turn = 0;
    private int deadTurn = 0;
    private char gender;
    private int pregnantTurn = 0;
    private int waterLevel;

    /**
     * Constructor. All Agilisaurus are represented by an 'U' and have 100 hit
     * points.
     *
     * @param name the name of this Agilisaur
     */
    public Agilisaurus(String name, char gender) {
        super(name, 'U', 100);
        foodLevel = 50;
        waterLevel = 50;
        behaviour = new WanderBehaviour();
        this.gender = gender;
    }

    public char getGender() {
        return gender;
    }

    @Override
    public Actions getAllowableActions(Actor otherActor, String direction, GameMap map) {
        return new Actions(new AttackAction(this));
    }

    @Override
    public Action playTurn(Actions actions, Action lastAction, GameMap map, Display display) {
        turn++;
        if (pregnantTurn != 0) {
            pregnantTurn++;
        }
        if (pregnantTurn == 10) {
            System.out.println("The female Agilisaurus lay an Agilisaurus egg");
            map.locationOf(this).setGround(new GrowingEgg('O'));
            map.locationOf(this).getGround().setDisplayChar('O');
            pregnantTurn = 0;
        }
        System.out.println(name + "'s food level is " + foodLevel);
        System.out.println(name + "'s water level is " + waterLevel);
        if (!isConscious()) {
            if (deadTurn == 20) {
                map.locationOf(this).addItem(new DeadDinosaur());
                map.removeActor(this);
            } else {
                deadTurn++;
                System.out.println(name + " at (" + map.locationOf(this).x() + "," + map.locationOf(this).y() + ") is unconcsious for turn " + deadTurn);
            }
        } else {
            deadTurn = 0;
            if (isHungry()) {
                if (isThirsty()) {
                    if (waterLevel < foodLevel) {
                        System.out.println(name + " at (" + map.locationOf(this).x() + "," + map.locationOf(this).y() + ") is thirsty");
                        Behaviour drink = new DrinkBehaviour();
                        Action drinking = drink.getAction(this, map);
                        foodLevel--;
                        if (waterLevel > 0) {
                            waterLevel--;
                        }
                        return drinking;
                    }
                }
                System.out.println(name + " at (" + map.locationOf(this).x() + "," + map.locationOf(this).y() + ") is getting hungry");
//            eatbehaviour
                Behaviour eat = new HerbivoreBehaviour();
                Action eating = eat.getAction(this, map);
                foodLevel--;
                if (waterLevel > 0) {
                    waterLevel--;
                }
                return eating;
            }
            if (isThirsty()) {
                System.out.println(name + " at (" + map.locationOf(this).x() + "," + map.locationOf(this).y() + ") is thirsty");
                Behaviour drink = new DrinkBehaviour();
                Action drinking = drink.getAction(this, map);
                foodLevel--;
                if (waterLevel > 0) {
                    waterLevel--;
                }
                return drinking;
            }
            if (!isPregnant() && foodLevel > 50 && gender == 'F') {
                Behaviour breed = new BreedingBehaviour();
                Action breeding = breed.getAction(this, map);
                foodLevel--;
                if (waterLevel > 0) {
                    waterLevel--;
                }
                return breeding;
            }
            Action wander = behaviour.getAction(this, map);
            if (wander != null) {
                foodLevel--;
                if (waterLevel > 0) {
                    waterLevel--;
                }
                return wander;
            }
            foodLevel--;
            if (waterLevel > 0) {
                waterLevel--;
            }
        }
        return new DoNothingAction();
    }

    public void eating(String str) {
        if (str.equals("DeadDinosaur")) {
            if (foodLevel + 30 <= MAX) {
                foodLevel += 30;
                System.out.println("Agilisaur eats Dead Dinosaur and increase 30 food level");
            }
        } else if (str.equals("StegosaurEgg")) {
            if (foodLevel + 10 <= MAX) {
                foodLevel += 10;
                System.out.println("Agilisaur eats Stegosaur Egg and increase 10 food level");
            }
        } else if (str.equals("CarnivoreMealKit")) {
            if (foodLevel + 50 <= MAX) {
                foodLevel += 50;
                System.out.println("Agilisaur eats Carnivore Meal Kit and increase 50 food level");
            }
        } else if (str.equals("Grass")) {
            if (foodLevel + 5 <= MAX) {
                foodLevel += 5;
                System.out.println("Agilisaur eats grass and increase 5 food level");
            }

        } else if (str.equals("Fruit")) {
            if (foodLevel + 30 <= MAX) {
                foodLevel += 30;
                System.out.println("Agilisaur eats fruit and increase 30 food level");
            }

        } else if (str.equals("Hay")) {
            if (foodLevel + 20 <= MAX) {
                foodLevel += 20;
                System.out.println("Agilisaur eats hay and increase 20 food level");
            }

        } else if (str.equals("HerbivoreMealKit")) {
            if (foodLevel + 50 <= MAX) {
                foodLevel += 50;
                System.out.println("Agilisaur eats Herbivore Meal Kit and increase 50 food level");
            }
        }
//        else if(item.toString()=="Leave"){
//            if(foodLevel+5<=MAX)
//            foodLevel+=5;
//        }
    }

    public void drinking() {
        waterLevel += 50;
        System.out.println("Agilisaur drinks water and increase 50 water level");
    }

    public boolean isConscious() {
        return foodLevel > 0;
    }

    public boolean isHungry() {
        return foodLevel <= 30;
    }

    public boolean isThirsty() {
        return waterLevel <= 30;
    }

    public void pregnant() {
        if (pregnantTurn == 0 && gender == 'F') {
            pregnantTurn = 1;
        }
    }

    public boolean isPregnant() {
        return pregnantTurn != 0;
    }

}

package game;

import java.util.Arrays;
import java.util.List;

import edu.monash.fit2099.engine.Actor;
import edu.monash.fit2099.engine.Display;
import edu.monash.fit2099.engine.FancyGroundFactory;
import edu.monash.fit2099.engine.GameMap;
import edu.monash.fit2099.engine.World;
import java.util.Scanner;

/**
 * The main class for the Jurassic World game.
 *
 */
public class Application {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Welcome to Jurassic World\nPlease select your game option :\n1. Challenge\n2. Sandbox\n3. Quit");
        int input = sc.nextInt();
        World world = new World(new Display());

        FancyGroundFactory groundFactory = new FancyGroundFactory(new Dirt(), new Wall(), new Floor(), new Tree(), new Water(), new VendingMachine());

        List<String> map = Arrays.asList(
                "................................................................................",
                "...................................~~...........................................",
                ".....#######......................~~~~..............................~~..........",
                ".....#_____#.......................~~..............................~~~~.........",
                ".....#_____#......................................................~~~~~~........",
                ".....###.###.......................................................~~~~.........",
                ".........V..........................................................~~..........",
                "...............~~.....................+++.......................................",
                "..............~~~~.....................++++.....................................",
                ".............~~~~~~................+++++........................................",
                "..............~~~~...................++++++.....................................",
                "...............~~.....................+++.......................................",
                ".....................................+++...................................~~...",
                "..........................................................................~~~~..",
                "............+++............................................................~~...",
                ".............+++++..............................................................",
                "...............++........................................+++++..................",
                ".............+++....................................++++++++....................",
                "............+++.......................................+++.......................",
                "................................................................................",
                "..................~~.....................................................++.....",
                ".................~~~~...................................................++.++...",
                "..................~~...................~~................................++++...",
                "......................................~~~~................................++....",
                ".......................................~~.......................................");
        while (input != 3) {
            GameMap gameMap = new GameMap(groundFactory, map);
            GameMap gameMap1 = new GameMap(groundFactory, map);
            world.addGameMap(gameMap);
            world.addGameMap(gameMap1); //second map

            Actor player = new Player("Player", '@', 100);
            world.addPlayer(player, gameMap.at(9, 4));

            // Place a pair of stegosaurs in the middle of the map
            gameMap.at(30, 12).addActor(new Stegosaur("Stegosaur", 'M'));
            gameMap.at(32, 12).addActor(new Stegosaur("Stegosaur", 'F'));

//            gameMap.at(1, 22).addActor(new Allosaur("Allosaur", 'M'));
//            gameMap.at(0, 24).addActor(new Allosaur("Allosaur", 'F'));

            if (input == 1) {
                System.out.println("You have selected the challenge type game. Enjoy !!!");
                System.out.println("Enter the number of move: ");
                int move = sc.nextInt();
                world.setMoves(move);
                System.out.println("Enter the number of eco points: ");
                int ecoPoint = sc.nextInt();
                world.setEcoPoints(ecoPoint);
                world.runChallenge();
            } else if (input == 2) {
                System.out.println("You have selected the sandbox type game. Enjoy !!!");
                world.runSandbox();
            } else if (input == 3) {
                System.out.println("You have quit the game");
            }
            System.out.println("\nWelcome to Jurassic World\nPlease select your game option :\n1. Challenge\n2. Sandbox\n3. Quit");
            input = sc.nextInt();
        }

    }
}

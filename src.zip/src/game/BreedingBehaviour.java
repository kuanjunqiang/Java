package game;

import edu.monash.fit2099.engine.*;

/**
 * A class that figures out a MoveAction that will move the actor one step
 * closer to a target Actor.
 */
public class BreedingBehaviour implements Behaviour {

    private Actor target;

    /**
     * Constructor.
     *
     */
    public BreedingBehaviour() {
    }

    @Override
    public Action getAction(Actor actor, GameMap map) {
        if (!map.contains(actor)) {
            return null;
        }

        int min = 100; // record the shortest distance between the actor and ground targer and actor will tend to move there
        int minX = 100;
        int minY = 100;
        // run through out whole map to find the nearest food
        for (int x = 0; x < 80; x++) {
            for (int y = 0; y < 25; y++) {
                Location here = map.locationOf(actor);
                Location there = map.at(x, y);
                
                if (map.at(x, y).getDisplayChar() == 'D' && ((Stegosaur)map.getActorAt(map.at(x, y))).getGender()!=((Stegosaur)actor).getGender()) {
                    int currentDistance = distance(here, there);
                    if (currentDistance < min) {
                        min = currentDistance;
                        minX = x;
                        minY = y;
                    }
                }

                if (map.at(x, y).getDisplayChar() == 'A' && ((Allosaur)map.getActorAt(map.at(x, y))).getGender()!=((Allosaur)actor).getGender()) {
                    int currentDistance = distance(here, there);
                    if (currentDistance < min) {
                        min = currentDistance;
                        minX = x;
                        minY = y;
                    }
                }
            }
        }
        Location here = map.locationOf(actor);
        Location there = map.at(minX, minY);
        int currentDistance = distance(here, there);
        for (Exit exit : here.getExits()) {
            Location destination = exit.getDestination();
            if (destination.canActorEnter(actor)) {
                if (currentDistance == 1&&!((Stegosaur)map.getActorAt(map.at(minX, minY))).isPregnant()) {
                    return new BreedAction();
                }
                else if(currentDistance==1){
                    
                }
                else {
                    int newDistance = distance(destination, there);
                    if (newDistance < currentDistance) {
                        return new MoveActorAction(destination, exit.getName());
                    }
                }

            }
        }
        return null;
    }

    /**
     * Compute the Manhattan distance between two locations.
     *
     * @param a the first location
     * @param b the first location
     * @return the number of steps between a and b if you only move in the four
     * cardinal directions.
     */
    private int distance(Location a, Location b) {
        return Math.abs(a.x() - b.x()) + Math.abs(a.y() - b.y());
    }
}

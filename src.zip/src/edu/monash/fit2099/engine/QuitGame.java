package edu.monash.fit2099.engine;

/**
 * An Action that doesn't do anything.  
 * 
 * Use this to implement waiting or similar actions in game clients.
 */
public class QuitGame extends Action {

	public QuitGame() {
	}

	@Override
	public String execute(Actor actor, GameMap map) {
        map.removeActor(actor);
        return menuDescription(actor);
    }

    @Override
    public String menuDescription(Actor actor) {
        return actor + " quit the game";
    }

    @Override
    public String hotkey() {
        return "Q";
	}
}

package edu.monash.fit2099.engine;

import game.GrowingEgg;

/**
 * Special Action that allows Actors to drop items.
 */
public class DropItemAction extends Action {

	protected Item item;

	/**
	 * Constructor.
	 *
	 * @param item the item to drop
	 */
	public DropItemAction(Item item) {
		this.item = item;
	}

	/**
	 * Drop the item.
	 *
	 * @param actor The actor performing the action
	 * @param map The map the actor is on
	 * @return a description of the action suitable for feedback in the UI
	 */
	@Override
	public String execute(Actor actor, GameMap map) {
		actor.removeItemFromInventory(item);
		map.locationOf(actor).addItem(item);
		if (item.getDisplayChar() == '0'){
			System.out.println("Player laid an Allosaur egg");
			map.locationOf(actor).setGround(new GrowingEgg('0'));
			map.locationOf(actor).getGround().setDisplayChar('0');
		}
		else if (item.getDisplayChar() == 'o'){
			System.out.println("Player laid a Stegosaur egg");
			map.locationOf(actor).setGround(new GrowingEgg('0'));
			map.locationOf(actor).getGround().setDisplayChar('0');
		}
		return menuDescription(actor);
	}

	/**
	 * A string describing the action suitable for displaying in the UI menu.
	 *
	 * @param actor The actor performing the action.
	 * @return a String, e.g. "Player drops the potato"
	 */
	@Override
	public String menuDescription(Actor actor) {
		return actor + " drops the " + item;
	}
}
